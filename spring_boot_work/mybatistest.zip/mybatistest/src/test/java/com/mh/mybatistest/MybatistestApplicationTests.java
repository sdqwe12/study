package com.mh.mybatistest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybatistestApplicationTests {

	@Test
	void contextLoads() {
	}

}
